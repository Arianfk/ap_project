// You can experiment here, it won’t be checked


package org.jetbrains.java.packages;
public class Task {
  public static void main(String[] args) {
    // put your code here
  }
}
