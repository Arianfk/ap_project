// You can experiment here, it won’t be checked
import java.util.Scanner;
class Task {
  public static void main(String[] args) {
    Cat myCat = new Cat("Maloos");
    int x = Integer.valueOf("123");
    System.out.println(myCat);
  }
}
