// declare your enum here

enum Currency {
    USD, EUR, GBP, RUB, UAH, KZT, CAD, JPY, CNY
}