abstract class Shape {

  abstract double getPerimeter();

  abstract double getArea();
}