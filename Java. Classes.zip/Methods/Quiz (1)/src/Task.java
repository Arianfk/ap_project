// You can experiment here, it won’t be checked

public class Task {
  public static void main(String[] args) {
    // put your code here
  }

  public int sum(int a, int b) {
    return a + b;
  }

  public int sum(int a) {
    return a + 10;
  }
}
